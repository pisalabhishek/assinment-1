# Insurance Claims Management Tool

## Setup
```bash
python -m venv venv
venv\Scripts\activate
pip install fastapi uvicorn
```

## Run
```bash
uvicorn app.main:app --reload
```

## API Endpoints
- POST /add_policyholder
- POST /add_claim